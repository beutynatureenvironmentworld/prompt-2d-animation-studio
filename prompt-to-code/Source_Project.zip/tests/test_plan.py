import json,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'python'))
from compile_prompt import compile_plan
class PlanTests(unittest.TestCase):
    def test_sinhala_door_prompt(self):
        x=compile_plan({'prompt':'ටොයිලට් එකට දුවගෙන ගිහින් දොරට තට්ටු කරන 2D විහිළු වීඩියෝවක් හදන්න','duration':5})
        self.assertIn('dash',[e['action'] for e in x['events']]);self.assertIn('knock',[e['action'] for e in x['events']])
    def test_unknown_fallback(self):
        x=compile_plan({'prompt':'abc'})
        self.assertEqual(len(x['events']),5)
    def test_duration_bounded(self):
        x=compile_plan({'prompt':'run','duration':100})
        self.assertEqual(x['duration'],9)
if __name__=='__main__':unittest.main()
