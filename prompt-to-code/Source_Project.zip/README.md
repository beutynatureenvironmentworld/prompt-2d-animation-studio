# Prompt-to-Code 2D Animation Studio — isolated experimental workflow

**Input:** Sinhala or English prompt, e.g. `ටොයිලට් එකට දුවගෙන ගිහින් දොරට තට්ටු කරන 2D විහිළු වීඩියෝවක් හදන්න`.

**Output:** Validated **JSON scene timeline** → code-drawn vector body/eyes/mouth/door → *real MP4* rendered with three different engines. **No pose PNGs or preassembled reference clips.** The prompt parser is a **deterministic offline keyword planner**; it is **not** a paid/free LLM. Optional `python/llm_planner.py` connects to an explicitly configured OpenAI-compatible LLM endpoint (opt-in; may incur charges) and validates restricted JSON before rendering. It does not execute untrusted LLM-generated code.

## Test and engine truth table

| Engine | Runtime / requirements | Test status |
|---|---|---|
| `python/render_svg.py` | CairoSVG+Pillow+FFmpeg, optional MoviePy/OpenCV; CPU no Chromium | Local generated original 5s/120-frame H.264/AAC MP4 in 2.08s (640x360) + 3 passing tests. GitHub Actions reruns it. |
| `remotion/` | React/TypeScript/SVG, Chromium/FFmpeg; Node >=18 | Dedicated GitHub Actions install-and-render test. Rendering success must be proven by MP4/ffprobe; subject to Remotion license eligibility. |
| `revideo/` | @revideo/2d/core/renderer + browser + FFmpeg, Node >=18 | Dedicated GitHub Actions install-and-render test. Sample sequence uses programmatic shapes; no static images. Browser/Node memory needs testing. |

**Note:** Remotion is **source-available under a proprietary Remotion License**, not OSI-approved open source. As of November 2026, solo creators/teams <=3 can generally use its Free License, including automation; check the latest terms: https://www.remotion.dev/docs/license. Revideo is MIT-licensed: https://github.com/midrender/revideo/blob/main/LICENSE.

## GitHub Actions / Oracle constraints

The workflow has three independent jobs: Python, Remotion, Revideo; GitHub Actions CPU runner has more resources than a small Oracle VPS. The current Oracle AI host `vidbest-ai-engine` has ~952 MiB RAM and ~2 GiB swap. **Only the Python+CairoSVG backend is suitable for a cautious low-memory VPS trial.** Chromium renderers are **not automatically installed/deployed** on Oracle to avoid impacting production services. This project is not attached to any existing production service.

## Run on GitHub

Go to `Actions -> Prompt-to-Code Pure Vector 2D Engine Comparison -> Run workflow` and enter `prompt`. The Python job writes `shared/scene.json`; Remotion and Revideo use bounded sample scenes based on the same storyline. **Revideo action timings are currently scripted**, and its generic JSON importer is not complete. A successful Revideo clip means Revideo rendered an original programmatic vector scene; it does not prove arbitrary prompts are supported yet.

To reproduce offline Python:

```bash
python -m pip install -r python/requirements.txt
python python/compile_prompt.py --input shared/prompt.json --output shared/scene.json
python python/render_svg.py --plan shared/scene.json --output output/python-svg-toon.mp4
```

## Rigging and character quality limitations

The renderer draws each character's *own vector shapes* per frame and changes eye/mouth/arms/legs. The art is deliberately monochrome and lightweight; not equivalent to the frame-by-frame acting of a polished cartoon studio. Prompt parsing supports only a finite action vocabulary: `notice`, `dash`, `knock`, `panic`, `recover`. For more actions/characters, extend grammar, templates, and safe planner schema. **Do not infer that 30-second 1080p renders can reliably finish in 5 seconds or 150 MB RAM.** Benchmark per host, fps and complexity.
