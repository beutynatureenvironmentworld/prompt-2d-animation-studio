"""Original prompt-driven SVG animation, all shapes computed from code at each frame.
No source mascot image and no static 6-pose sprites are required.
CairoSVG (SVG rasterizer) + Pillow + rawvideo FFmpeg + original SFX.
"""
import io,os,math,json,time,subprocess,struct,wave,argparse,sys
from pathlib import Path
from PIL import Image
import cairosvg
from compile_prompt import validate

def current_scene(plan,t):
    for event in plan['events']:
        if t < event['end']:
            z=(t-event['start'])/(event['end']-event['start'])
            return event['action'], max(0,min(1,z))
    return plan['events'][-1]['action'],1

def svg_frame(plan,t):
    action,z=current_scene(plan,t)
    # Every limb and expression is drawn anew; no head/face overlays.
    speed=math.sin(t*2*math.pi*5.1)
    if action=='notice': x=140;foot=0;bend=0;eyemode='neutral'
    elif action=='dash': x=140+275*z;foot=speed;bend=16;eyemode='wide'
    elif action=='knock': x=420;foot=0;bend=7;eyemode='focus'
    elif action=='panic': x=420-55*z;foot=0;bend=-25;eyemode='shock'
    else: x=365-25*z;foot=0;bend=0;eyemode='smile'
    y=272+(6*abs(speed) if action=='dash' else 0)
    shakex=5*math.sin(t*48) if action=='panic' else 0
    x+=shakex
    a1,a2=(45*speed,-45*speed) if action=='dash' else (0,0)
    l1,l2=(-42*speed,42*speed) if action=='dash' else (0,0)
    if action=='knock':a1=-20+45*math.sin(z*math.pi*8);a2=8
    if action=='panic':a1=-90;a2=90;l1=30;l2=-35
    if action=='recover':a1=-8;a2=10
    eyes={'neutral':(5,5,0),'wide':(7,9,-4),'focus':(5,5,3),'shock':(9,11,-3),'smile':(5,4,0)}[eyemode]
    blink=(math.sin(t*4.3)>0.994) and action!='panic'
    pupil_y=eyes[2]
    left_eye=f'<ellipse cx="-18" cy="-174" rx="{eyes[0]}" ry="{1 if blink else eyes[1]}" fill="white" stroke="#1a1a1a" stroke-width="2"/><circle cx="-16" cy="{-172+pupil_y}" r="{0 if blink else 3}" fill="#151515"/>'
    right_eye=f'<ellipse cx="18" cy="-174" rx="{eyes[0]}" ry="{1 if blink else eyes[1]}" fill="white" stroke="#1a1a1a" stroke-width="2"/><circle cx="20" cy="{-172+pupil_y}" r="{0 if blink else 3}" fill="#151515"/>'
    if action=='panic': mouth='<ellipse cx="0" cy="-143" rx="12" ry="16" fill="#222"/>'
    elif action=='recover':mouth='<path d="M -19 -147 Q 0 -128 20 -147" stroke="#222" fill="none" stroke-width="3"/>'
    elif action=='knock': mouth='<path d="M -12 -146 Q 0 -141 12 -146" stroke="#222" fill="none" stroke-width="3"/>'
    else:mouth='<path d="M -11 -145 L 12 -145" stroke="#222" fill="none" stroke-width="3"/>'
    # Draw near-front and behind-facing limbs in full body coordinate system.
    def arm(angle,side):
        ax=side*29; ay=-91
        return f'<g transform="translate({ax},{ay}) rotate({angle})"><path d="M 0 0 L {side*7} 39 L {side*14} 63" stroke="#111" stroke-width="15" stroke-linecap="round" fill="none"/><circle cx="{side*14}" cy="63" r="9" fill="white" stroke="#111" stroke-width="3"/></g>'
    def leg(angle,side):
        lx=side*16;ly=-42
        return f'<g transform="translate({lx},{ly}) rotate({angle})"><path d="M 0 0 L {side*8} 45 L {side*8} 76" stroke="#161616" stroke-width="15" stroke-linecap="round" fill="none"/><ellipse cx="{side*10+12}" cy="78" rx="20" ry="10" fill="white" stroke="#111" stroke-width="4"/></g>'
    speedlines=''
    if action=='dash':
        speedlines=''.join(f'<path d="M {x-120-i*7:.1f} {y-120+i*21:.1f} h -{55+i*9}" stroke="#292929" stroke-width="{2+i%2}"/>' for i in range(4))
    if action=='panic':speedlines=f'<g stroke="#111" stroke-width="4"><path d="M {x-70} {y-215} l -25 -24 M {x+70} {y-220} l 22 -28"/></g>'
    # Ortho camera composition + understated flat-color background, but character monochrome.
    svg=f'''<svg xmlns="http://www.w3.org/2000/svg" width="640" height="360" viewBox="0 0 640 360">
      <rect width="640" height="360" fill="#f8f7f3"/>
      <rect x="0" y="290" width="640" height="70" fill="#e7e5dc"/>
      <path d="M 0 290 H640" stroke="#b1afa4" stroke-width="3"/>
      <rect x="470" y="92" width="125" height="202" rx="3" fill="#f0ede5" stroke="#222" stroke-width="7"/>
      <rect x="488" y="122" width="86" height="142" rx="3" fill="#fbfaf5" stroke="#222" stroke-width="3"/>
      <circle cx="563" cy="203" r="6" fill="#222"/>
      <rect x="477" y="64" width="111" height="29" rx="4" fill="#222"/><text x="532" y="85" fill="#fff" text-anchor="middle" font-size="19" font-family="Arial" font-weight="bold">TOILET</text>
      {speedlines}
      <ellipse cx="{x}" cy="294" rx="42" ry="7" fill="#c0bdb4" opacity=".5"/>
      <g transform="translate({x:.2f},{y:.2f})">
        {leg(l1,-1)}{leg(l2,1)}
        {arm(a1,-1)}
        <g transform="rotate({bend},0,-90)">
          <path d="M -35 -115 Q 0 -131 35 -115 L 29 -45 Q 0 -33 -29 -45 Z" fill="white" stroke="#111" stroke-width="5"/>
          <path d="M -5 -115 L 0 -92" fill="none" stroke="#222" stroke-width="3"/>
          <circle cx="0" cy="-174" r="42" fill="white" stroke="#111" stroke-width="5"/>
          <path d="M -42 -188 Q -43 -219 -16 -218 L -7 -233 L 5 -217 L 26 -222 L 41 -195 L 24 -206 Q -4 -207 -16 -199 Z" fill="#171717"/>
          {left_eye}{right_eye}
          {mouth}
        </g>
        {arm(a2,1)}
      </g>
      <text x="15" y="28" font-family="Arial" font-size="13" fill="#666">ORIGINAL CODE-DRAWN 2D / {action.upper()}</text>
    </svg>'''
    return svg

def sfx(file,duration):
    sr=16000; events=[(0.5,470,.09),(1.4,320,.13),(2.2,560,.06),(3.15,250,.1),(3.75,190,.26),(4.4,500,.14)]
    with wave.open(str(file),'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(sr)
        out=bytearray()
        for i in range(round(sr*duration)):
            t=i/sr;value=0
            for st,f,l in events:
                dt=t-st
                if 0<=dt<l:
                    value+=math.sin(2*math.pi*(f-80*dt)*dt)*(1-dt/l)**2*8500
            out+=struct.pack('<h',max(-32767,min(32767,int(value))))
        w.writeframes(out)

def run(plan,output):
    validate(plan)
    output=Path(output);output.parent.mkdir(parents=True,exist_ok=True)
    wf=plan['width'];hf=plan['height'];fps=plan['fps'];dur=plan['duration'];n=round(fps*dur)
    silent=output.with_name('silent_'+output.name);audio=output.with_suffix('.wav')
    args=['ffmpeg','-y','-hide_banner','-loglevel','error','-threads','2','-f','rawvideo','-pix_fmt','rgb24', '-s',f'{wf}x{hf}','-r',str(fps),'-i','-','-an','-c:v','libx264','-preset','veryfast','-crf','23','-pix_fmt','yuv420p',str(silent)]
    p=subprocess.Popen(args,stdin=subprocess.PIPE)
    start=time.monotonic()
    try:
        for i in range(n):
            svg=svg_frame(plan,i/fps)
            bytes_png=cairosvg.svg2png(bytestring=svg.encode(),output_width=wf,output_height=hf)
            im=Image.open(io.BytesIO(bytes_png)).convert('RGB')
            p.stdin.write(im.tobytes())
        p.stdin.close()
    except Exception:
        p.kill();raise
    if p.wait(): raise RuntimeError('FFmpeg encoder failed')
    sfx(audio,dur)
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(silent),'-i',str(audio),'-c:v','copy','-c:a','aac','-shortest','-movflags','+faststart',str(output)],check=True)
    wall=round(time.monotonic()-start,2)
    try:silent.unlink()
    except:pass
    meta={'engine':'Python CairoSVG + Pillow + FFmpeg','input_plan':plan,'newly_generated_vector_frames':n,
          'render_seconds':wall,'video_file':str(output),'actual_video_verified':output.stat().st_size>10000,
          'llm_inference_used':False,'gpu_video_inference_used':False,'not_still_image_zoom':True}
    output.with_suffix('.json').write_text(json.dumps(meta,indent=2,ensure_ascii=False))
    return meta
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--plan',default='shared/scene.json');ap.add_argument('--output',default='output/python-svg-toon.mp4');args=ap.parse_args()
    result=run(json.loads(Path(args.plan).read_text()),args.output)
    print('PYTHON_CAIROSVG_ACTUAL_MP4_PASS',result['video_file'],result['newly_generated_vector_frames'],result['render_seconds'])
