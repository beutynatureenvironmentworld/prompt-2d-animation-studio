"""Opt-in OpenAI-compatible LLM planning adapter, deliberately NOT run by CI.
No arbitrary LLM-written program is executed. Use only validated JSON action plans.
Your provider account may charge API usage; enable explicitly via --llm.
"""
import os, urllib.request, json, argparse, pathlib
from compile_prompt import validate

def create_plan(text):
    base=os.environ.get('LLM_API_BASE','').rstrip('/')
    key=os.environ.get('LLM_API_KEY','')
    model=os.environ.get('LLM_MODEL','')
    if not base or not model:raise RuntimeError('LLM_API_BASE and LLM_MODEL must be set explicitly')
    if not base.startswith('https://') and not base.startswith('http://127.0.0.1:'):
        raise RuntimeError('LLM_API_BASE must be HTTPS or localhost for test')
    system=('Return ONLY JSON object. schema toon-prompt-v1; width 640,height 360,fps 24,duration 5; '
            'events must be ordered and cover [0,5] continuously. Actions limited to '
            'notice,dash,knock,panic,recover. Never return executable source code. '
            'Also include input_prompt and authoring="LLM constrained JSON".')
    payload={'model':model,'temperature':0.2,'messages':[{'role':'system','content':system},
             {'role':'user','content':text[:400]}]}
    headers={'Content-Type':'application/json'}
    if key:headers['Authorization']='Bearer '+key
    req=urllib.request.Request(base+'/chat/completions',data=json.dumps(payload).encode(),headers=headers,method='POST')
    with urllib.request.urlopen(req,timeout=45) as response:
        data=json.load(response)
    message=data['choices'][0]['message']['content']
    result=json.loads(message)
    validate(result)
    return result
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('prompt');p.add_argument('--output',default='shared/scene.json');a=p.parse_args()
    plan=create_plan(a.prompt);pathlib.Path(a.output).write_text(json.dumps(plan,ensure_ascii=False,indent=2))
    print('LLM_VALIDATED_ACTION_PLAN_WRITTEN',a.output)
