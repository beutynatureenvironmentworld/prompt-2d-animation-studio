"""Constrained prompt -> safe action JSON. Offline keyword fallback, not an LLM.
Optional LLM planners may emit this same validated JSON schema; never execute
untrusted model-generated Python/JS code.
"""
import argparse, json, pathlib, re
ACTIONS=('notice','dash','knock','panic','recover')
PHRASES={
 'notice':['see','notice','look','දැක','බල'],
 'dash':['run','rush','sprint','dash','දුව','වේග'],
 'knock':['knock','tap','door','දොර','තට්ටු'],
 'panic':['scared','panic','shock','surprise','බය','ගැස්','පුදුම'],
 'recover':['recover','laugh','smile','laughing','අවසාන','හිනා']
}
def compile_plan(src):
    raw=src['prompt'][:400]
    p=raw.casefold()
    selected=[name for name,terms in PHRASES.items() if any(term in p for term in terms)]
    if not selected: selected=list(ACTIONS)
    # Always place in story chronology: deterministic puppet actions.
    selected=[name for name in ACTIONS if name in selected]
    if len(selected)<3:
        selected=[name for name in ACTIONS if name in {*selected,'notice','recover'}]
    length=min(max(float(src.get('duration',5)),2.0),9.0)
    weights={'notice':0.55,'dash':1.6,'knock':1.2,'panic':.8,'recover':.75}
    scale=length/sum(weights[x] for x in selected)
    events=[];t=0.0
    for name in selected:
        d=weights[name]*scale
        events.append({'action':name,'start':round(t,3),'end':round(t+d,3)})
        t+=d
    events[-1]['end']=length
    plan={'schema':'toon-prompt-v1','input_prompt':raw,'authoring':'offline constrained storyboard compiler (not LLM)',
          'width':int(src.get('width',640)),'height':int(src.get('height',360)),
          'fps':int(src.get('fps',24)),'duration':length,'events':events}
    validate(plan)
    return plan

def validate(d):
    assert d.get('schema')=='toon-prompt-v1'
    assert 320<=d['width']<=1920 and 240<=d['height']<=1080
    assert 12<=d['fps']<=30 and 1<=d['duration']<=9
    assert 1<=len(d['events'])<=8
    p=0
    for e in d['events']:
        assert e['action'] in ACTIONS and e['start']>=p-.01 and e['end']>e['start']
        p=e['end']
    assert abs(p-d['duration'])<.02

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--input',default='shared/prompt.json');parser.add_argument('--output',default='shared/scene.json');a=parser.parse_args()
    result=compile_plan(json.loads(pathlib.Path(a.input).read_text()))
    pathlib.Path(a.output).parent.mkdir(parents=True,exist_ok=True)
    pathlib.Path(a.output).write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print('PROMPT_TO_VALIDATED_JSON',[(e['action'],e['start'],e['end']) for e in result['events']])
