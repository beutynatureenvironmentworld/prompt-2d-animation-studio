import {renderVideo} from '@revideo/renderer';
import {mkdirSync} from 'node:fs';
async function main(){
  mkdirSync('out',{recursive:true});
  const file=await renderVideo({projectFile:'./src/project.ts',settings:{
    outDir:'out',outFile:'toon-revideo.mp4',range:[0,5],workers:1,dimensions:[640,360],logProgress:true,
    ffmpeg:{ffmpegPath:'ffmpeg',ffmpegLogLevel:'error'},puppeteer:{args:['--no-sandbox']}
  }});
  console.log('REVIDEO_REAL_MP4_RENDERED',file);
}
main().catch(err=>{console.error('REVIDEO_RENDER_FAILED',err.message);process.exit(1)});
