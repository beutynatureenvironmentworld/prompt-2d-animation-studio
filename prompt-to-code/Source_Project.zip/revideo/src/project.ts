import {makeProject} from '@revideo/core';
import scene from './scene';
export default makeProject({name:'Toon Prompt Revideo',scenes:[scene],settings:{
  shared:{background:'#f8f7f3',range:[0,5],size:{x:640,y:360}},
  preview:{fps:24,resolutionScale:1},
  rendering:{exporter:{name:'@revideo/core/wasm'},fps:24,resolutionScale:1,colorSpace:'srgb'}
}});
