/** @jsxImportSource @revideo/2d/lib */
import {Circle,Rect,Txt,makeScene2D} from '@revideo/2d';
import {all,createRef,waitFor} from '@revideo/core';
// All elements created dynamically; no external image or pre-generated posing.
export default makeScene2D('toilet-dash',function*(view){
  view.fill('#f8f7f3');
  const actor=createRef<Rect>();
  const face=createRef<Circle>();
  const mouth=createRef<Rect>();
  const door=createRef<Rect>();
  view.add(<>
    <Rect x={0} y={142} width={640} height={75} fill={'#e7e5dc'}/>
    <Rect ref={door} x={218} y={-2} width={125} height={202} fill={'#f7f5ee'} stroke={'#111'} lineWidth={6}/>
    <Rect x={218} y={-100} width={116} height={30} fill={'#111'}/>
    <Txt text={'TOILET'} x={218} y={-100} fontSize={18} fill={'white'}/>
    <Rect ref={actor} x={-170} y={68} width={63} height={80} fill={'white'} stroke={'#111'} lineWidth={5}>
      <Rect x={-18} y={62} width={14} height={74} fill={'#171717'}/>
      <Rect x={18} y={62} width={14} height={74} fill={'#171717'}/>
      <Rect x={-40} y={0} width={14} height={65} rotation={-15} fill={'#171717'}/>
      <Rect x={40} y={0} width={14} height={65} rotation={15} fill={'#171717'}/>
      <Circle ref={face} x={0} y={-72} width={85} height={85} fill={'#fff'} stroke={'#111'} lineWidth={5}>
        <Circle x={-17} y={-5} size={11} fill={'#111'}/>
        <Circle x={17} y={-5} size={11} fill={'#111'}/>
        <Rect ref={mouth} x={0} y={25} width={28} height={4} fill={'#111'}/>
      </Circle>
    </Rect>
  </>);
  yield* waitFor(.65);                    // notice
  yield* all(actor().x(30,1.65),actor().rotation(12,1.65)); // dash
  yield* all(actor().rotation(0,.35),door().rotation(4,.35)); // knock
  yield* all(face().scale(1.16,.4),mouth().height(18,.4)); // shock reaction
  yield* all(actor().rotation(-14,.45),actor().x(-40,.45));
  yield* all(actor().rotation(0,.35),face().scale(1,.35),mouth().height(4,.35)); // recover
  yield* waitFor(.6);
});
