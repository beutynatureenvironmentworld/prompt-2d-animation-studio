import React from 'react';
import {AbsoluteFill,useCurrentFrame,useVideoConfig} from 'remotion';
import plan from './scene.json';
type Action='notice'|'dash'|'knock'|'panic'|'recover';
const actions=plan.events as Array<{action:Action;start:number;end:number}>;
function actionAt(t:number):{action:Action;z:number}{
  for(const e of actions){if(t<e.end)return {action:e.action,z:Math.min(1,Math.max(0,(t-e.start)/(e.end-e.start)))}}
  return {action:'recover',z:1};
}
export const Toon:React.FC=()=>{
 const f=useCurrentFrame();const {fps}=useVideoConfig();const t=f/fps;
 const {action,z}=actionAt(t);
 const v=Math.sin(t*Math.PI*2*5.1);
 let x=140,lean=0,aL=0,aR=0,lL=0,lR=0;
 if(action==='dash'){x=140+275*z;lean=14;aL=v*44;aR=-v*44;lL=-v*39;lR=v*39}
 if(action==='knock'){x=420;lean=6;aR=-33+48*Math.sin(z*18)}
 if(action==='panic'){x=420-55*z;lean=-22;aL=-88;aR=88;lL=35;lR=-35}
 if(action==='recover'){x=365-25*z}
 const y=272+(action==='dash'?6*Math.abs(v):0);
 const mouth=action==='panic'?<ellipse cx="0" cy="-143" rx="11" ry="15" fill="#222"/>:action==='recover'?<path d="M -19 -148 Q 0 -125 19 -148" fill="none" stroke="#111" strokeWidth="3"/>:<path d="M -12 -147 H 12" stroke="#111" strokeWidth="3"/>;
 const arm=(a:number,s:number)=><g transform={`translate(${29*s} -91) rotate(${a})`}><path d={`M0 0 L${s*7} 42 L${s*14} 64`} fill="none" stroke="#171717" strokeWidth="15" strokeLinecap="round"/><circle cx={14*s} cy={64} r="8" stroke="#111" strokeWidth="3" fill="white"/></g>;
 const leg=(a:number,s:number)=><g transform={`translate(${16*s} -42) rotate(${a})`}><path d={`M 0 0 L${s*8} 47 L${s*8} 76`} stroke="#111" strokeWidth="15" fill="none" strokeLinecap="round"/><ellipse cx={s*10+10} cy="78" rx="19" ry="9" stroke="#111" strokeWidth="3" fill="white"/></g>;
 return <AbsoluteFill style={{backgroundColor:'#f8f7f3'}}>
 <svg viewBox="0 0 640 360" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
 <rect y="290" width="640" height="70" fill="#e7e5dc"/><path d="M0 290H640" stroke="#aaa" strokeWidth="2"/>
 <rect x="470" y="92" width="125" height="202" fill="white" stroke="#222" strokeWidth="6"/>
 <rect x="490" y="122" width="85" height="145" fill="#f7f5ed" stroke="#222" strokeWidth="3"/><circle cx="563" cy="202" r="6"/>
 <rect x="477" y="64" width="111" height="29" rx="4" fill="#222"/><text x="532" y="85" textAnchor="middle" fill="white" fontSize="18" fontWeight="bold">TOILET</text>
 {action==='dash'&&[0,1,2].map(i=><line key={i} x1={x-105} x2={x-157-i*10} y1={y-112+i*30} y2={y-112+i*30} stroke="#222" strokeWidth="3"/>)}
 <ellipse cx={x} cy="295" rx="40" ry="7" fill="#b7b6ae" opacity="0.5"/>
 <g transform={`translate(${x} ${y})`}>
 {leg(lL,-1)}{leg(lR,1)}{arm(aL,-1)}
 <g transform={`rotate(${lean} 0 -90)`}>
 <path d="M-35 -115Q0 -131 35 -115L29 -45Q0 -33 -29 -45Z" fill="white" stroke="#111" strokeWidth="5"/>
 <circle cx="0" cy="-174" r="42" fill="white" stroke="#111" strokeWidth="5"/>
 <path d="M-41 -190Q-38 -215 -18 -218L-7 -234L8 -215L24 -221L41 -195L25 -206Q-4 -210 -17 -199Z" fill="#111"/>
 {[-18,18].map((cx,i)=><g key={i}><ellipse cx={cx} cy="-174" rx="7" ry={action==='panic'?10:7} fill="white" stroke="#111" strokeWidth="2"/><circle cx={cx+2} cy="-172" r="3" fill="#111"/></g>)}
 {mouth}
 </g>{arm(aR,1)}</g>
 <text x="15" y="28" fontSize="13" fill="#666">REMOTION / CODE DRAWN / {action.toUpperCase()}</text>
 </svg>
 </AbsoluteFill>;
};
