import React from 'react';
import {Composition} from 'remotion';
import {Toon} from './toon';
import plan from './scene.json';
export const Root:React.FC=()=><Composition id="FunnyToon" component={Toon} width={640} height={360} fps={24} durationInFrames={Math.round(plan.duration*24)}/>;
